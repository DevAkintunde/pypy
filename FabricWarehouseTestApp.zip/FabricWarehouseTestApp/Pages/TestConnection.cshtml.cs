﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using FabricWarehouseTestApp.Services;

namespace FabricWarehouseTestApp.Pages
{
    public class TestConnectionModel : PageModel
    {
        private readonly FabricWarehouseService _fabricWarehouseService;

        public TestConnectionModel(FabricWarehouseService fabricWarehouseService)
        {
            _fabricWarehouseService = fabricWarehouseService;
        }

        public string ConnectionResult { get; private set; }
        public string QueryResult { get; private set; }

        public async Task OnGetAsync()
        {
            ConnectionResult = await _fabricWarehouseService.TestConnectionAsync();
            QueryResult = await _fabricWarehouseService.ExecuteQueryAsync("SELECT TOP 5 * FROM YourTableName");
        }
    }
}