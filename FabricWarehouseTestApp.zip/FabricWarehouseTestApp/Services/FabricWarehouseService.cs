using Microsoft.Data.SqlClient;
using System.Data;

namespace FabricWarehouseTestApp.Services
{
    public class FabricWarehouseService
    {
        private readonly string _connectionString;

        public FabricWarehouseService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("FabricWarehouse");
        }

        public async Task<string> TestConnectionAsync()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    return "Connection to Fabric Warehouse successful!";
                }
            }
            catch (Exception ex)
            {
                return $"Connection failed: {ex.Message}";
            }
        }

        public async Task<string> ExecuteQueryAsync(string query)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    using (var command = new SqlCommand(query, connection))
                    {
                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            var result = new System.Text.StringBuilder();
                            while (await reader.ReadAsync())
                            {
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    result.Append($"{reader.GetName(i)}: {reader.GetValue(i)}, ");
                                }
                                result.AppendLine();
                            }
                            return result.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return $"Query execution failed: {ex.Message}";
            }
        }
    }
}