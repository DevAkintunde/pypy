from flask import Flask, Response 
import logging

app = Flask(__name__) 

@app.get("/test-flask") 
def test(): 
    logging.info('Route successfully called here !!!')
    return Response("<h1>Hello World™</h1>", mimetype="text/html") 
  
