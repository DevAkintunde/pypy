import azure.functions as func
from FlaskApp.flask_app import app

# Ensure this is the entry point for the Azure Functions runtime
def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    """
    Each request is redirected to the WSGI handler.
    """
    # Wrap the Flask app's WSGI app with Azure Functions' WSGI middleware
    return func.WsgiMiddleware(app.wsgi_app).handle(req, context)
